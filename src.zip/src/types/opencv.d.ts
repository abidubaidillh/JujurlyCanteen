interface Window {
  cv: any;
}